package com.th.controller;

import java.io.IOException;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.th.constants.SystemConstants;
import com.th.model.Admin;
import com.th.model.Book;
import com.th.repository.AdminRepository;
import com.th.service.AdminService;



@Controller
public class AdminController {
	
	@Autowired
	AdminRepository adminRepostitory;
	
	@Autowired
	AdminService adminService;
	
	@GetMapping(value = SystemConstants.ADMIN)
	public String adminlogin(Model model){
		Admin admin = new Admin();
		model.addAttribute("admin", admin);
		return "adminLogin";
	}
	

	
    @RequestMapping(value = SystemConstants.ADMIN_LOGIN, method = RequestMethod.POST)
	public ModelAndView authenticationAdmin(Admin admin) {

		return adminService.findByAdminId(admin);

	}

	@PostMapping(SystemConstants.ADMIN_ADD)
	public ModelAndView addBook(Book book, @RequestParam("bookimg") MultipartFile file) throws IOException {

		return adminService.addBook(book, file);

	}

	@PostMapping(SystemConstants.ADMIN_DELETE)
	public ModelAndView deleteBookById(Integer bookId) {

		ModelAndView modelAndView = adminService.removeBook(bookId);
		return modelAndView;

	}
	
	
	
	@PostMapping(SystemConstants.ADMIN_UPDATE)
	public ModelAndView UpdateBookById(Book book, @RequestParam("bookimg") MultipartFile file) throws IOException {

		ModelAndView modelAndView = adminService.updateBook(book, file);
		return modelAndView;

	}
	
	@GetMapping(value = SystemConstants.SEARCHBOOK)
	public String bookSearch(String bookname, Model model) throws IOException{
		return adminService.bookSearch(bookname, model);
	}
	

}



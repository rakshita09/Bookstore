package com.th.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.th.constants.SystemConstants;
import com.th.model.PasswordUpdate;
import com.th.model.User;
import com.th.repository.UserRepository;
import com.th.service.UserService;


@Controller
public class UserController {
	
	@Autowired
	UserRepository userRepostitory;
	
	@Autowired
	UserService userService;
	
	
//	
//	@GetMapping(value = SystemConstants.LOGIN)
//	public String userlogin(Model model){
//		User user = new User();
//		model.addAttribute("user", user);
//		return "login";
//	
//	}
	
	
	@GetMapping(value = SystemConstants.LOGIN)
	public ModelAndView  userlogin(Model model){
		return userService.UserLogin(model);
	
	}
	@RequestMapping(value = SystemConstants.USER_LOGIN, method = RequestMethod.POST)
	public ModelAndView authenticationUser(User user, Model model) {

		return userService.findByUserEmail(user, model);

	}
	


	@PostMapping(value = SystemConstants. USER_REGISTER)
	public String Userregister( User user) {

	User registerduser = null;
	if(null != user) {
	registerduser = new User(user.getUseremail(),user.getName(),user.getPassword());
	}
	userRepostitory.save(registerduser);
	return "redirect:/login?success";
	}


	@RequestMapping(value = SystemConstants.USER_PASS_CHANGE, method = RequestMethod.POST)
	public String passwordChange(PasswordUpdate passwordUpdate) {

		return userService.passwordChange(passwordUpdate);

	}
	

//	@RequestMapping(value = SystemConstants.USER_PASS_CHANGE, method = RequestMethod.POST)
//	public ModelAndView  passwordChange(PasswordUpdate passwordUpdate) {
//
//		return userService.passwordChange(passwordUpdate);
//
//	}
//	
	
	
	@GetMapping(value = SystemConstants.SEARCH)
	public String bookSearch(String bname, String useremail, Model model) {
		return userService.bookSearch(bname,useremail, model);
	}
	
	
	
}

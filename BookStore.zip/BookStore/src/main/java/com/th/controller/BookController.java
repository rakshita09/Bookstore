package com.th.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.th.constants.SystemConstants;
import com.th.model.Book;
import com.th.repository.BookRepository;

@RestController
@RequestMapping(SystemConstants.BOOK)
public class BookController {
	
	
	@Autowired
	BookRepository bookRepository;
	
	
	@PostMapping(SystemConstants.BOOK)
	public ResponseEntity<Book> save (@RequestBody Book book){
		
		Book bookSaved = bookRepository.save(book);
		return new ResponseEntity<Book>(bookSaved,HttpStatus.OK);
	}
	
	
	 
	@GetMapping(SystemConstants.GET_ALL_BOOKS)
	public  ResponseEntity<List<Book>> getAllBooks(){
		
		List<Book> bookList = bookRepository.findAll();
		return new ResponseEntity<List<Book>>(bookList,HttpStatus.OK);
	}
	
	

	@GetMapping(SystemConstants.FIND_BOOK)
	public ResponseEntity<Book> getBookById(@PathVariable Integer bookId){
		
		Optional<Book> bookOptional = bookRepository.findById(bookId);
		if(bookOptional.isPresent()) {
			Book bookFound = bookOptional.get();
			return new ResponseEntity<Book>(bookFound,HttpStatus.OK);
			
		}
		else
			return new  ResponseEntity<Book>(HttpStatus.NOT_FOUND);
		
	}

	
	
	@DeleteMapping(SystemConstants.DELETE_BOOK)
	public ResponseEntity<Book> deleteBookById(@PathVariable Integer bookId){
		if(bookRepository.existsById(bookId)) {
			bookRepository.deleteById(bookId);
			return new ResponseEntity<Book>(HttpStatus.NO_CONTENT);
		}
			return new ResponseEntity<Book>(HttpStatus.NOT_FOUND);
	}
	
	
}

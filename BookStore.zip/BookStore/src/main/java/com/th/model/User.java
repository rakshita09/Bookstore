package com.th.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name ="user")
public class User {
	@Id
	private String useremail;
	
	private String password;
	private String name;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUseremail() {
		return useremail;
	}
	public void setUseremail(String useremail) {
		this.useremail = useremail;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	public User(String useremail, String password, String name) {
		super();
		this.useremail = useremail;
		this.password = password;
		this.name = name;
	}
	public User() {
		
	}
	@Override
	public String toString() {
		return "User [useremail=" + useremail + ", password=" + password + ", name=" + name + "]";
	}
	
	
	

}


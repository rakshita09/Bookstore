package com.th.model;

import java.sql.Timestamp;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "book")
public class Book implements  Comparable<Book>{
@Id	
 private Integer bookId;
 private String bookname;
 private double bookprice;
 private String genre;
 private byte[] bookimage;
 private Timestamp booktimestamp = null;


public Integer getBookid() {
	return bookId;
}
public void setBookid(Integer bookid) {
	this.bookId = bookid;
}
public String getBookname() {
	return bookname;
}
public void setBookname(String bookname) {
	this.bookname = bookname;
}

public double getBookprice() {
	return bookprice;
}
public void setBookprice(double bookprice) {
	this.bookprice = bookprice;
}
public String getGenre() {
	return genre;
}
public void setGenre(String genre) {
	this.genre = genre;
}



public byte[] getBookimage() {
	return bookimage;
}
public void setBookimage(byte[] bookimage) {
	this.bookimage = bookimage;
}
public Timestamp getBooktimestamp() {
	return booktimestamp;
}
public void setBooktimestamp(Timestamp booktimestamp) {
	this.booktimestamp = booktimestamp;
}

public Book(Integer bookId, String bookname, String author, double bookprice, String genre)
		 {
	super();
	this.bookId = bookId;
	this.bookname = bookname;
	this.bookprice = bookprice;
	this.genre = genre;
	
}
public Book() {
	
}

@Override
public int compareTo(Book o) {
	if (bookprice == o.getBookprice())
		return 0;
	else if (bookprice < o.getBookprice())
		return 1;
	else
		return -1;

}
@Override
public String toString() {
	return "Book [bookId=" + bookId + ", bookname=" + bookname + ", bookprice=" + bookprice + ", genre=" + genre + "]";
}


 
 

}

package com.th.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.th.model.Book;

@Repository
public interface BookRepository extends JpaRepository<Book, Integer> {
	@Query(value = "select * from Book b where b.bookname like %:bookname%", nativeQuery = true)
	public abstract Optional<Book> FindByBookName(String bookname);
}

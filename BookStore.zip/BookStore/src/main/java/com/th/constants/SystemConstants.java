package com.th.constants;

public class SystemConstants {

	
	public static final String  LOGIN = "/login";
	
	public static final String  USER_LOGIN = "/userLogin";
	
	public static final String  USER_REGISTER = "/userregister";
	
	public static final String  ADMIN = "/admin";
	
	public static final String  ADMIN_LOGIN = "/adminLogin";
	
	public static final String ADMIN_ADD = "/admin/addbook";
	
	public static final String ADMIN_DELETE = "/admin/delete";
	
	public static final String ADMIN_UPDATE = "/admin/update";
	
	public static final String SEARCHBOOK = "/admin/search";
	
	public static final String SEARCH = "/search";
	
	public static final String USER_PASS_CHANGE = "/passwordchange";
	
    public static final String BOOKS = "/books";

	public static final String BOOK = "/book";
	
	public static final String GET_ALL_BOOKS = "/getallbooks";
	
	public static final String FIND_BOOK = "/getbookbyid/{bookId}";
	
	
	public static final String DELETE_BOOK = "/deletebook/{bookId}";
	
	
	
}



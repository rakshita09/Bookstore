package com.th.service;

import java.io.IOException;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.th.model.Admin;
import com.th.model.Book;

public interface AdminService {
	
	
	public ModelAndView removeBook(Integer bookId);
	
	public ModelAndView addBook(Book book,@RequestParam("bookimg") MultipartFile file)throws IOException;

	public ModelAndView updateBook(Book book,@RequestParam("bookimg") MultipartFile file)throws IOException;
	
	 public String bookSearch(String bookname, Model model)throws IOException;
	
	 public ModelAndView findByAdminId(Admin admin);

}

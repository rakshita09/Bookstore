package com.th.service;

import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;

import com.th.model.PasswordUpdate;
import com.th.model.User;

public interface UserService {
	
	public String passwordChange(PasswordUpdate passwordUpdate);
//	 public ModelAndView passwordChange(PasswordUpdate passwordUpdate);
	    
	  public ModelAndView findByUserEmail(User user,Model model);
	  
	  
	  public String bookSearch(String bname ,String useremail, Model model);

	  public ModelAndView UserLogin(Model model);
	

}
